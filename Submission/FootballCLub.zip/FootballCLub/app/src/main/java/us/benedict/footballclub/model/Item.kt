/*
*
* Submission 1 : Aplikasi Football Club
* Author : Benedict E. Pranata (benedict.erwin@gmail.com)
* Date: 5 September 2018
*
* */

package us.benedict.footballclub.model

/* Item Class - Data Abstraction */
data class Item (val name: String?, val image: Int?, val desc: String?)